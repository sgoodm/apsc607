


## Project 01


**Report** - project_01.pdf

**Figures and Table** - All figures and the final table (CSV) can be found in the output directory

**main.m** - core code where input functions/variables are set. Manages running functions and handles all outputs.


**bisection.m, newton.m, secant.m** - code containing functions for each method


