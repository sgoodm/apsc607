function [y2] = cent_diff_v2(h,p,q,r,N,alpha,beta)
%%% Central difference method but for A(N+2xN+2) matrix
% INPUT:
% h = step size
% p,q,r functions based on linear differential equation y'' = py'+ qy + r
% N = amount of steps
% alpha : y(a) = alpha
% beta : y(b) = beta

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create diagonal elements

% Diagonal

% Diagonal - 1

% Diagonal + 1

% Solution vector b

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve linear system

% Use your own developed Matlab code, or use the build in Matlab function
% (but less points will be given for using build-in Matlab)

% y2 =

end

