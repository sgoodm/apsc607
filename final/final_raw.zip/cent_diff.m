function [y] = cent_diff(h,p,q,r,N,alpha,beta)
%%% Central difference method
% INPUT:
% h = step size
% p,q,r functions based on linear differential equation y'' = py'+ qy + r
% N = amount of steps (and size of matrix)
% alpha : y(a) = alpha
% beta : y(b) = beta

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Create diagonal elements

% Diagonal


% Diagonal - 1


% Diagonal + 1


% Solution vector b

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Solve linear system

% Use your own developed Matlab code, or use the build in Matlab function
% (but less points will be given for using build-in Matlab)



% Make the full length y solution by including the boundary values.
% y =

end

